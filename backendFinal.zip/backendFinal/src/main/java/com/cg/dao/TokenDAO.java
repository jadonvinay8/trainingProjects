package com.cg.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.bean.Token;

public interface TokenDAO extends JpaRepository<Token, Integer>{

}
