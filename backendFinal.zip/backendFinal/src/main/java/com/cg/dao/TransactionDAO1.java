package com.cg.dao;



import java.sql.Date;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.cg.bean.Transaction;



@Repository
public interface TransactionDAO1 {
	public int useridorder(int orderid);

	public List<Integer> productidorder(int orderid);

	public int productquantityorder(int orderid);

	public Date dateorder(int orderid);

	public Transaction getTransaction(int orderid);
}
