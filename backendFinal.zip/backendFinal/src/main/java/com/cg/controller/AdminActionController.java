package com.cg.controller;


import java.io.IOException;
import java.sql.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.cg.bean.Discount;
import com.cg.bean.Merchant;
import com.cg.bean.Product;

import com.cg.bean.Promocode;
import com.cg.bean.User1;

import com.cg.exception.MerchantNotFoundException;
import com.cg.exception.ProductNotFoundException;
import com.cg.model.ResponseMessage;
import com.cg.service.AdminServices;
import com.cg.service.PhotoUpload;

@CrossOrigin("http://localhost:4200")
@RestController
@RequestMapping("/admin")
public class AdminActionController {
	
	

	@Autowired
	private AdminServices adminService;
	
		
	

  // ------------------------------------------------Discount----------------------------------------------------------------------------------- -----------------------------------------------------------------
	/*
	 * Discount given by admin on particular product
	 * 
	 */
	
	@GetMapping(value = "/AllDiscounts")
	public List<Discount> AllDiscounts() {
     
      return adminService.AllDiscounts();
	}
	
	@GetMapping(value = "/findDiscount/{discountId}")
	public Discount findDiscount(@PathVariable("discountId") int discountId) {
     
      return adminService.findDiscount(discountId);
	}
	
	
	@PostMapping(value = "/addDiscount",consumes= {"application/json"})
	public String addDiscount(@RequestBody Discount discount) {
     
        
		adminService.addDiscount(discount);
		return "Discount Added";
	}
	
	@PutMapping(value = "/updateDiscount",consumes= {"application/json"})
	public String updateDiscount(@RequestBody Discount discount) {
     
        
		adminService.updateDiscount(discount);
		return "Discount updated";
	}

	@DeleteMapping("/deleteDiscount/{discountId}")
	public String removeDiscount(@PathVariable("discountId") int discountId) {
		adminService.removeDiscount(discountId);
		return "Discount deleted";
	}
	
	//Required for discount Module================================================================
	
	@GetMapping(value = "/AllProducts")
	public List<Product> AllProducts() {
		// to view all the available customers
		
		return adminService.AllProducts();
	}
	


	@GetMapping(value = "/findProduct/{productId}")
	public Product findProduct(@PathVariable("productId") int productId) {
     
      return adminService.findProduct(productId);
	}
		
		
		//Required for discount Module=============================================================
		
	
	
	
	//-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

	
	
	
	
	//--------------------------------------------User---------------------------------------------------------------------------------------------------------------------------------------------------
	@GetMapping(value = "/AllUsers")
	public List<User1> AllUsers() {
		// to view all the available customers
		
		return adminService.AllUsers();
	}
	
	@DeleteMapping("/deleteUser/{userId}")
	public String removeUser(@PathVariable("userId") int userId) {
		adminService.removeUser(userId);
		return "User deleted";
	}

	//---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
	
	
	
	
	//----------------------------------------------------------Merchant----------------------------------------------------------------------------------------------------------------------------
	
	
	ResponseMessage resMsg;

	@GetMapping(value = "/AllMerchants")
	public ResponseMessage getAllMerchants() {

		List<Merchant> merchantsList = adminService.getAllMerchant();
		if(merchantsList==null || merchantsList.isEmpty()) {
		resMsg = new ResponseMessage("Merchant Records Not Found", 404, null, null);
		return resMsg;
		}
		else
		{	System.out.println(merchantsList);
			resMsg = new ResponseMessage("Merchants Record Found", 200, merchantsList, null);
			return resMsg;
		}
		
	}

	@GetMapping(value = "/find/{emailid}")
	public ResponseMessage findByEmailId(@PathVariable String emailid) {

		Merchant merchantObject;
		try {
			merchantObject = adminService.findMerchantByEmail(emailid);
		} catch (RuntimeException e) {
			resMsg = new ResponseMessage("Merchant Not Found", 404, null, null);
			return resMsg;

		}
		resMsg = new ResponseMessage("Merchant Found", 200, null, merchantObject);
		return resMsg;
	}

	@PostMapping(value = "/new", consumes = { "application/json" })
	public ResponseMessage save(@RequestBody Merchant merchantObject) {

		try {
			adminService.addMerchant(merchantObject);
		} catch (RuntimeException ex) {
			resMsg = new ResponseMessage("Merchant Already Exists", 409, null, merchantObject);
			return resMsg;

		}
		resMsg = new ResponseMessage("Merchant Record Added", 200, null, merchantObject);
		return resMsg;
	}

	@PutMapping(value = "/update", consumes = { "application/json" })
	public ResponseMessage update(@RequestBody Merchant merchantObject) {

		try {
			adminService.updateMerchant(merchantObject);
		} catch (RuntimeException e) {
			resMsg = new ResponseMessage("Merchant Record Not Found", 404, null, null);
			return resMsg;

		}resMsg = new ResponseMessage("Merchant Record Updated", 200, null, null);
		return resMsg;
	}

	@DeleteMapping(value = "/delete/{merchantId}")
	public ResponseMessage delete(@PathVariable Integer merchantId) {
		System.out.println("In Delete Request");
		try {
			adminService.removeMerchant(adminService.findMerchantById(merchantId));
		} catch (RuntimeException e) {
			resMsg = new ResponseMessage("Merchant Record Not Found", 404, null, null);
			return resMsg;
		}
		resMsg = new ResponseMessage("Merchant Record Deleted", 200, null, null);
		return resMsg;
	}
	private final PhotoUpload fileService;



	  public AdminActionController(PhotoUpload fileService) {

	 this.fileService = fileService;

	 }


	 @CrossOrigin("http://localhost:4200")
	 @PostMapping(value = "/api/files")
	 public void handleFileUpload(@RequestParam("file") MultipartFile file) throws IOException {

	 fileService.storeFile(file);

	 }

	
	//-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
	
	
	
	
	//-----------------------------------------------------------------Product--------------------------------------------------------------------------------------------------------------------------
	
	
	@PostMapping(value="/products/add", consumes= {"application/json"})
	public int addProduct(@RequestBody Product product) throws ProductNotFoundException {
		product.setReleaseDate(new Date(2019,8,24));
		adminService.addProduct(product);
		return 0;
	}
	@PutMapping(value="/products/update", consumes= {"application/json"})
	public Product updateProduct(@RequestBody Product product) {
		try {
			adminService.updateProduct(product);
			return product;
		}catch(Exception e) {
			return null;
		}
	}

	@GetMapping(value="products/getmerchantbyid/{merchantId}") 
	public Merchant getMerchantById(@PathVariable("merchantId") Integer merchantId) throws MerchantNotFoundException {
		return adminService.getMerchantById(merchantId);
	}
	
	
	@GetMapping(value="products/all")
	public @ResponseBody List<Product> getAllProduct() {
		
		
		List<Product> product = adminService.getAllProducts();
		return product;
	}
	
	@DeleteMapping(value="products/delete/{productID}")
	public void removeProduct(@RequestParam("merchantId") int merchantId,@PathVariable int productId) {
		Merchant merchant;
		try {
		merchant=adminService.getMerchantById(merchantId);
		
		adminService.removeProduct(productId);
		}
		catch (ProductNotFoundException e) {

		}
		 catch (MerchantNotFoundException e) {

			}
	
	}
    //----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------


	
	
  //---------------------------------------------------------------------------PromoCode--------------------------------------------------------------------------------------------------------------------
	@GetMapping("/AllPromocodes") // Get mapping for getting list of sessions
	public List<Promocode>  getAllPromos() {
		return adminService. getAllPromos();
	}
	
	@PostMapping(value = "/addPromocode", consumes = { "application/json" }) // to add session into the database
	public String save(@RequestBody Promocode p) {
		adminService.addPromo(p);
		return "Promo added!";
	}
	
	@DeleteMapping(value = "/deletePromoCode/{id}") // to delete session from database using id
	public String deleteUser(@PathVariable int id) {
		adminService.deletePromo(id);
		return "Promo deleted";
	}

	
	//---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

	//----------------TPMerchant-----------------------------
	
	
	
		@PostMapping(value="/addTPMerchant", consumes= {"application/json"})
		public String addTPMerchant(@RequestBody Merchant t) {
			return adminService.addAccount(t);
		}
		
		/*@DeleteMapping(value="/deleteTPMerchant/{mid}")
		public String deleteTPMerchant(@PathVariable int mid) {
			tpmService.delete(mid);
			return "Third Party Merchant deleted";
		}*/
		
		@PutMapping(value="/updateTPMerchant/{id}", consumes= {"application/json"})
		public String updateTPMerchant(@RequestBody Merchant t, @PathVariable int id) {
			adminService.update(id, t);
			return "Third Party Merchant updated";
		}
		
		@GetMapping(value="/tpMerchant", produces= {"application/json"})
		public List<Merchant> getAllTPMerchant(){
			return adminService.getAllTpmerchant();
		}	
		
		
		
		//----------------TPMerchant-------------------------------------------------------------------
		
		
		
		
		
		@PostMapping(value="/addTPProduct", consumes= {"application/json"})
		public String add(@RequestBody Product p) {
			return adminService.addTpProduct(p);
		}
		
		/*@DeleteMapping(value="/deleteProduct/{pid}")
		public String deleteProduct(@PathVariable int pid) {
			pService.delete(pid);
			return "Product deleted";
		}*/
		
		@PutMapping(value="/updateTPProduct/{id}", consumes= {"application/json"})
		public String updateProduct(@RequestBody Product p, @PathVariable int id) {
			adminService.update(id, p);
			return "Product updated";
		}
		
		@GetMapping(value="/TPproduct", produces= {"application/json"})
		public List<Product> getAllTpProduct(){
			return adminService.getAllTpproduct();
		}
		
		//----------------TPMerchant------------------------------------------------------------------------
		
		


}
