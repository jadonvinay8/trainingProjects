package com.cg.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.cg.bean.SecurityAns;


public interface PasswordForgotService {

	public String getPassword(String email, String category,String ans1,String ans2);
	
}
