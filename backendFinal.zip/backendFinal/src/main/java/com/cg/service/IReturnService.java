package com.cg.service;

import java.util.List;

import com.cg.bean.Return;

public interface IReturnService {
	
	public List<Return> getAllReturnDetails();
	
	public Return addrecordtoreturn(int temp);
	
	public List<Integer> getTransaction(int id);
//
//	public String addTransaction(Transaction t);
//
//	public List<Transaction> getAllTransactions();
	
//	public Return checkstatus(int orderid);
	

	

//	public List<Return> getreturngoods();



}
