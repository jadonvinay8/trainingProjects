export interface DepositAndWithdrawFormat{

    id: number
    amount: number
}