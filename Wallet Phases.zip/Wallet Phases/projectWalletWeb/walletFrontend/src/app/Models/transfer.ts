export interface TransferFormat{
    id1:number
    id2:number
    amount:number
}