

export interface Account{
    id:number
    phone:string
    accountHolder:string
    balance:number
    
}