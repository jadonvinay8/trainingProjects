import { Invoice } from "./Invoice";
import { Product1 } from "./Product";

export class InvoiceProduct {

    invoiceObject: Invoice;
    productsList: Product1[];
}