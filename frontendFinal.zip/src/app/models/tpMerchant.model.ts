export class TPMerchant{
    merchantId:number;
    company:string;
    emailid:string;
    firstName:string;
    lastName:string;
    mobileno:number;
    status:string;

}