export class SecurityAns{

    emailId:string;
    answer1:string;
    answer2:string;

    constructor(emailId:string,answer1:string,answer2:string){

        this.emailId=emailId;
        this.answer1=answer1;
        this.answer2=answer2;
    }

}