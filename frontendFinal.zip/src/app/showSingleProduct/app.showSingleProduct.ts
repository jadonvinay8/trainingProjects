import { Component,} from "@angular/core";
import {ProductSingleService} from '../Services/showSingleProductService';
import {Product} from '../models/Product';
import {Router, RouterModule, Routes} from '@angular/router';

@Component({
    selector:'show-product',
    templateUrl:'showproduct.html'
})

export class ShowProductSingleComponent {
    constructor(private service:ProductSingleService, private router:Router){

    }
    products:Product[]=[];

    similarProducts: Product[] = []

    product:Product;
   

    pid: string;
    uid: string;


    ngOnInit(): void {
       // throw new Error("Method not implemented.");
       this.pid = sessionStorage.getItem('productId')
        this.uid = sessionStorage.getItem("user")        
        this.service.findproduct(this.pid).subscribe(
            res=>{
               this.product=res
                this.service.getsimilarProduct(this.product.category, this.product.subcategory, this.product.productID).subscribe(
                    data=>{
                        this.similarProducts = data;
                    }, err=>console.log(err)
                )
            },
            err=>{
                alert("an error has occurred")
            }
        )
        
        //this.finddata();
       } 

       addToWishlist(){
        this.service.addWishList(this.pid,this.uid);
       }
       addToCart(){
         this.service.addCart(this.pid,this.uid);
       }

       showProduct(index: number){
        let productId = this.similarProducts[index].productID;
        sessionStorage.setItem('productId',""+productId)
        //let a = sessionStorage.getItem('productId')
        window.location.reload();
       }
}