import { Component, OnInit } from "@angular/core";
import { TPMerchant } from '../../models/tpMerchant.model';
import {AdminService} from '../../services/app.adminService';
import { TPProduct } from '../../models/TPproduct.model';
import { FormBuilder, FormGroup } from "@angular/forms";
import { FileUploader } from 'ng2-file-upload'


@Component({
    selector: 'tpm',
    templateUrl: './tpMerchant.html'
})

export class ManageTPMerchant implements OnInit{
    
  uploader: FileUploader;
  isDropOver: boolean;
    tpmerchants: TPMerchant[];
    tpmerchant: TPMerchant = new TPMerchant();
    id:number=null;
    tpStatus=false;
    pro=false;
    products: TPProduct[];
    product: TPProduct = new TPProduct();
    aProduct: TPProduct = new TPProduct();
    pStatus=false;
    addStatus=false;
    validpro=false;

    constructor(private tpmerchantservice: AdminService, private fb: FormBuilder){}


    categoryForm: FormGroup;
    filler:number
    ngOnInit(){
        this.tpmerchantservice.getTPMerchant()
        .subscribe(data => {
            this.tpmerchants = data;
        });

        this.tpmerchantservice.getTPProduct()
        .subscribe(data => {
            this.products = data;
        });
        this.filler=Math.random()
        const headers = [{name: 'Accept', value: 'application/json'},{name:'Number',value:this.filler.toString()}];

   this.uploader = new FileUploader({url: 'http://localhost:5000/admin/api/files', autoUpload: true, headers: headers});

   this.uploader.onCompleteAll = () => alert('File uploaded');
    }

    reset(){
        this.pro = false;
        this.pStatus=false;
        this.tpStatus=false;
        this.addStatus=false;
        this.validpro=false;
    }

    /*deleteTPMerchant(tpmerchant: TPMerchant): void {
        this.tpmerchantservice.deleteTPMerchant(tpmerchant).subscribe(data => {
            this.tpmerchants = this.tpmerchants.filter(u => u !==tpmerchant);
        });
        //window.location.reload();
    };*/

    editTPMerchant(data: TPMerchant):void{
        this.tpStatus=!this.tpStatus;
        this.tpmerchant.company=data.company;
        this.tpmerchant.firstName=data.firstName;
        this.tpmerchant.lastName=data.lastName;
        this.tpmerchant.emailid=data.emailid;
        this.tpmerchant.mobileno=data.mobileno;
        this.tpmerchant.status=data.status;
        this.tpmerchant.merchantId=data.merchantId;
        this.pStatus=false;
        this.pro=false;
        this.addStatus=false;
    }
    updateTPMerchant(){
        this.tpmerchantservice.updateTPMerchant(this.tpmerchant).subscribe(data => { console.log("updated")});
        this.tpStatus=false;
        window.location.reload();
    }
    onFileChanged(event){

        this.product.photo="D:\\Users\\vinaypsi\\Desktop\\frontendFinal\\src\\assets\\images\\"+this.filler+event.target.files[0].name
    
      }

    showProduct(){
        this.pro=!this.pro;
        this.tpStatus=false;
        this.pStatus=false;
        this.addStatus=false;
        for(let data of this.products){
            if(this.id==data.merchant.merchantId){
                this.validpro=true;
            }
        }
    }

    /*deleteProduct(product: Product): void {
        this.tpmerchantservice.deleteProduct(product).subscribe(data => {
            this.products = this.products.filter(u => u !==product);
        });
        //window.location.reload();
    }*/

    editProduct(data: TPProduct): void {
        this.pStatus=!this.pStatus;
        this.product.productID=data.productID;
        this.product.productName=data.productName;
        console.log(data.tag)
        this.product.tag=data.tag;
        console.log(this.product.tag)
        this.product.company=data.company;
        this.product.photo=data.photo;
        this.product.description=data.description;
        this.product.quantity=data.quantity;
        this.product.category=data.category;
        this.categoryForm = this.fb.group({
            categoryControl: [this.product.category]
          });
        this.product.subcategory=data.subcategory;
        this.product.soldQuantities=data.soldQuantities;
        this.product.price=data.price;
        this.product.releaseDate=data.releaseDate;
        this.product.merchant=data.merchant;
        this.tpStatus=false;
        this.addStatus=false;
    }


    onChange($event){
        this.aProduct.category= $event.target.options[$event.target.options.selectedIndex].value;
        console.log(this.aProduct.category)
        }

        onChange2($event){
            this.product.category= $event.target.options[$event.target.options.selectedIndex].value;
            console.log(this.product.category)
            }

    updateProduct(){
        this.tpmerchantservice.updateTPProduct(this.product).subscribe(data => { console.log("updated")});
        this.pStatus=false;
        window.location.reload();
    }

    createProduct(data: TPMerchant){
        this.aProduct.merchant=data;
        this.aProduct.category = "Electronics";
        console.log(this.aProduct.merchant.merchantId);
        this.addStatus=!this.addStatus;
        this.pStatus=false;
        this.pro=false;
        this.tpStatus=false;
    }

    addProduct(): void {
        this.aProduct.soldQuantities=0;
        this.aProduct.tag.push(this.aProduct.company);
        this.tpmerchantservice.addProduct(this.aProduct).subscribe();
        this.addStatus=false;
        window.location.reload();
    }

}