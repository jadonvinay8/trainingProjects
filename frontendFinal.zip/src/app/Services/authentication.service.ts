import { Injectable, OnInit } from '@angular/core'

@Injectable({
  providedIn: 'root'
})
export class AuthenticationService implements OnInit {

  ngOnInit(): void {
    
  }

  public status: boolean
  constructor() { }
  count:number;

  isUserLoggedIn() {
    // this.count = sessionStorage.length
    // alert(this.count)
    if (this.count != 0) {
      return true
    }
    else {
      return false
    }
  }

  logout() {
    this.count = sessionStorage.length
    if(this.count == 0)
    {
      alert("You Are Not Logged In Yet!!!")
    }
    else{
      alert("Successfully Logged Out")
    }

    sessionStorage.clear()
  }

}

